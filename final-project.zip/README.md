## my Dependencies in this project :
the project uses webpack version 4 , babel v6.23.0,
@babel/runtime v7.11.2, body-parser v1.19.0, cors v2.8.5, dotenv 8.2.0 , express v4.17.1 , webpack-cli v3.3.5 , jest v26.5.3 and some loaders
## References that i have used in project :
i used w3 schools for some javascript syntax and stackoverflow for fixing some bugs and geeks for geeks to calculate number of days and knowledge platform helped me Specifically mentor mohga , webpack documentions , web apis documentions 
## Brief about important files in my project :
app.js cause it has all javascript that written in project , style.scss cause it has all styles in the project and it makes the project appear nice , index.js cause it importing all data in the project in one file
## how to run the project in development mode :
after you have installed all loaders and webpack and all things in the project from terminal you can run development mode by just typing npm run build-dev
## how to run the project in production mode. :
after you have installed all loaders and webpack and all things in the project from terminal you can run development mode by just typing npm run build-prod
## how to run express server : 
just type npm run start
## about project
in the project you put your start date and end date and name of country 
and the project returns some informtion
##  Extend your Project Further - Roadmap/Strategy :
i used this from all options Add end date and display length of trip.