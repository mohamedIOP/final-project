/* Global Variables */
//the exported function
const allApplication = (()=>{
const generateButton = document.getElementById('generate');
//get api keys
const getData = async ()=>{
    const req = await fetch('/getApis');
    try{
        const finalData = await req.json();
        console.log(finalData)
        return finalData
        //check console.log(finalData);
    }catch(error){
        console.log('error',error)
    }
}
// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+ 1 + '-'+ d.getDate()+'-'+ d.getFullYear();
//contact with api 
const getNewData = async (input)=>{
    console.log(input);
    const infoApi = await fetch(input);
    try{
        const apiData = await infoApi.json();
        console.log(apiData)
        return apiData;
    }catch(error){
        console.log('error',error);
    }
}
if(generateButton != null){
    generateButton.addEventListener('click',callback);
}
function callback(){
    const startDate = document.querySelector('#startDate').value;
    const endDate = document.querySelector('#endDate').value;
    const timeDiference = (dateFirst,dateSecond)=>{//the part of calculation the difference of date is taken from geeks for geeks and it not be me 
        const date1 = new Date(dateFirst);
        const date2 = new Date(dateSecond);
        // To calculate the time difference of two dates 
        var Difference_In_Time = date2.getTime() - date1.getTime(); 
        // To calculate the no. of days between two dates 
        var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    return Difference_In_Days}
    const dateForWeather = ()=>{
        if(Math.floor(timeDiference(newDate,startDate)) >= 16){
            return 15
        }
        else{
            return Math.floor(timeDiference(newDate,startDate))
        }
    };
    //base urls for apis
    const geourl = 'http://api.geonames.org/postalCodeSearchJSON?';
    const weatherurl = 'https://api.weatherbit.io/v2.0/forecast/daily?';
    const pixbayurl = 'https://pixabay.com/api/?';
    const projectData = {}
    getData()
    .then(function(finalData){
        const country = document.querySelector('#country').value;
        const geoFull = `${geourl}placename=${country}&maxRows=1&username=${finalData.geoname}`
        getNewData(geoFull)
        .then(function(apiData){
            const lat = apiData.postalCodes[0].lat;
            const lng = apiData.postalCodes[0].lng;
            const weatherFull = `${weatherurl}lat=${lat}&lon=${lng}&key=${finalData.weatherbit_KEY}`;
            console.log(weatherFull)
            getNewData(weatherFull)
            .then(function(fulldata){
                projectData.minTemp = fulldata.data[dateForWeather()].min_temp;
                projectData.maxTemp = fulldata.data[dateForWeather()].max_temp;
                projectData.weatherDes = fulldata.data[dateForWeather()].weather.description;
                const pixabayFull = `${pixbayurl}key=${finalData.pixbay_KEY}&q=${country}&category=places&image_type=photo`;
                getNewData(pixabayFull)
                .then(function(photoinfo){
                    projectData.photo = photoinfo.hits[0].webformatURL;
                    const tripLength = timeDiference(startDate,endDate);
                    const finalDate = Math.floor(timeDiference(newDate,startDate));
                    document.getElementById('Photo').innerHTML = `<img src="${projectData.photo}">`
                    document.getElementById('Date').innerHTML = `Trip Start at :<strong>${startDate}</strong><br>Trip End at <strong>${endDate}</strong><br>Trip Begain after:${finalDate} Days,Trip length : ${tripLength}`
                    document.getElementById('temp').innerHTML = `Minimum Temperature :<strong>${projectData.minTemp}</strong><br>Maximum Temperature: <strong>${projectData.maxTemp}</strong><br>Weather Description: <strong>${projectData.weatherDes}`
                })
            })
        })
    });} 
})();
//exportData
export {
    allApplication
}