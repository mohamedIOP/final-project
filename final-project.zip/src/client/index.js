import { allApplication } from './js/app'
import './styles/style.scss'

export {
    allApplication
}